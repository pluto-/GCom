package gcom.utils;

/**
 * Created by Jonas on 2014-11-01.
 */
public interface VectorClockListener {
    public void vectorClockUpdated(VectorClock newVectorClock);
}
