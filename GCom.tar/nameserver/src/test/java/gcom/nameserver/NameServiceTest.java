package gcom.nameserver;

import junit.framework.TestCase;

public class NameServiceTest extends TestCase {

    public void testJoinGroup() throws Exception {

    }

    public void testRemoveGroup() throws Exception {

    }

    public void testSetLeader() throws Exception {

    }
}