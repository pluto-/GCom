package gcom.communicator;

import junit.framework.TestCase;

public class CommunicatorTest extends TestCase {

    public void testMulticast() throws Exception {

    }

    public void testReceiveMessage() throws Exception {

    }

    public void testViewChanged() throws Exception {

    }

    public void testElectLeader() throws Exception {

    }

    public void testSendViewChange() throws Exception {

    }
}